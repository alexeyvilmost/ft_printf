/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa_base.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pallspic <pallspic@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/17 18:43:10 by pallspic          #+#    #+#             */
/*   Updated: 2019/07/17 19:26:21 by pallspic         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static char	overbase(t_ushort n, char letter)
{
	if (n < 10)
		return (n + '0');
	else
		return (ft_isupper(letter) ? n + 55 : n + 87);
}

char 		*ft_itoa_base(t_llong num, t_ushort base, char letter)
{
	char 	*ret;
	t_ullong nb;
	t_ullong mult;
	size_t 	i;

	i = 0;
	ret = ft_strnew(ft_nsize(num, base));
	nb = (num > 0) ? num : -num;
	ret[i] = (num > 0) ? '\0' : '-' * (++i);
	mult = ft_nmult(num, base);
	while (mult)
	{
		ret[i++] = overbase(nb / mult, letter);
		nb -= (nb / mult) * mult;
		mult /= base;
	}
	ret[i] = '\0';
	return (ret);
}