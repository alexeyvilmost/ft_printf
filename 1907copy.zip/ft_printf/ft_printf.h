/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: pallspic <pallspic@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/06 18:50:22 by pallspic          #+#    #+#             */
/*   Updated: 2019/07/18 18:38:03 by pallspic         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#ifndef FT_PRINTF
#define FT_PRINTF

#include "libft/libft.h"
#include <stdarg.h>
#include <limits.h>
#include <stdio.h>

# define UNSIGN 'u'
# define SIMPLE_INT "diu"
# define BASE_INT "oxX"
# define F_2 127
# define D_2 1023
# define LD_2 16383
# define MANT 8388608;

/*
** ============================# Structures #===================================
*/

typedef struct	s_type
{
	char 		*flag;
	int			accur;
	int			size;
	char 		type;
	char 		spec;
}				t_type;

typedef union
{
	long double		main;
	struct 			s_ems
	{
		unsigned long	mant : 64;
		unsigned short	expo : 15;
		_Bool			sign : 1;
	}			mem;
}				t_double;

/*
** ==============================# Utilities #==================================
*/

t_type	pf_new_list(void);
t_type	prepare_data(t_type data);
void	pf_write(int symbol, size_t amount);
_Bool	in(const char *who, const char *what);

/*
** ================================# Forks #====================================
*/

void	pf_int_fork(t_type data, va_list arg);
void	pf_type_fork(t_type data, va_list arg);
int 	pf_get_flags(const char *restrict s, size_t *i, va_list buff);

/*
** ============================# Print functions #==============================
*/

int		ft_printf(const char *restrict format, ... );
void	pf_put_chr(t_type data, va_list arg);
void	pf_put_short(t_type data, va_list arg);
void	pf_put_float(t_type data, va_list arg);
void	pf_put_string(t_type data, va_list arg);
void	pf_put_pointer(t_type data, va_list arg);
void	pf_put_flags(t_type data, char *n, short i, short neg);
void	pf_put_base(t_type data, t_llong n);

#endif
